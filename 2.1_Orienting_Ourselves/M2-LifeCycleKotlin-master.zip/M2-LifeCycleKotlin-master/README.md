# M2-LifeCycleKotlin
Starter Kotlin code for the module 2 task on Life Cycle.
